// simple finishedEdge class for data storage
public class finishedEdge {
    public int router1;
    public int router2;
    public finishedEdge(int first, int second){
        router1 = first;
        router2 = second;
    }
}