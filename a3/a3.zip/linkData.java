// Link cost data structure
public class linkData {
    public int link;  /* link id */
    public int cost;  /* associated cost */

    public linkData(int l, int c){
        link = l;
        cost = c;
    }
}